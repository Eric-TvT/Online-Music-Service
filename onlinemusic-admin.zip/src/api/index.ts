import { deletes, get, getBaseURL, post } from './request'
const HttpManager = {
    // 获取图片信息
    attachImageUrl: (url) => `${getBaseURL()}${url}`,
    // =======================> 管理员 API 完成
    // 是否登录成功
    // 是否登录成功
    getLoginStatus: ({ username, password }) => post(`admin/login/status`, { username, password }),

    // =======================> 用户 API 完成
    // 返回所有用户
    getAllUser: (curPage,pageSize) => get(`user?curPage=`+curPage+'&pageSize='+pageSize),
    // 返回指定ID的用户
    getUserOfId: (id) => get(`user/detail?id=${id}`),
    // 删除用户
    deleteUser: (id) => get(`user/delete?id=${id}`),
    //删除多个用户
    deleteUsers: (ids) => deletes(`user/deleteIds?${ids}`),

    // =======================> 收藏列表 API 完成
    // 返回的指定用户ID收藏列表
    getCollectionOfUser: (userId) => get(`collection/detail?userId=${userId}`),
    // 删除收藏的歌曲
    deleteCollection: (userId, songId) => deletes(`collection/delete?userId=${userId}&&songId=${songId}`),

    // =======================> 评论列表 API 完成
    // 获得指定歌曲ID的评论列表
    getCommentOfSongId: (songId) => get(`comment/song/detail?songId=${songId}`),
    // 获得指定歌单ID的评论列表
    getCommentOfSongListId: (songListId) => get(`comment/songList/detail?songListId=${songListId}`),
    // 删除评论
    deleteComment: (id) => get(`comment/delete?id=${id}`),
}

export { HttpManager }