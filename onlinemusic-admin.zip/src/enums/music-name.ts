export const MUSICNAME = 'Online-Music 后台管理'
