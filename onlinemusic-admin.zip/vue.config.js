const { defineConfig } = require('@vue/cli-service')

module.exports = defineConfig({
    lintOnSave: false,
    transpileDependencies: true,
    chainWebpack: config => {
        config.plugin('define').tap(definitions => {
            Object.assign(definitions[0]['process.env'], {
                //配置变量NODE_HOST方便访问远程服务器
                NODE_HOST: '"http://localhost:8888"',
            });
            return definitions;
        });
    }
})